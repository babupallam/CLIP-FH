Note:
 - baseline inference: functions needed for baseline model
 - evaluator: the functions needed for evaluation
 - finetune_trainer.py                 ✅ frozen text encoder
 - clipreid_trainer.py                 ✅ prompt + two-stage strategy
 - third_trainer.py            ✅ image + text both trainable
