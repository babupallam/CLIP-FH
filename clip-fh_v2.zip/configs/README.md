Note
    - now baseline config has been added

│   ├── train_stage1_frozen_text/           ✅ Stage 1: freeze text, tune image encoder


===========

│   ├── train_stage2_loss_variants/         ✅ Stage 2: loss function experiments


│   ├── train_stage3_clipreid/              ✅ Stage 3: CLIP-ReID strategy (2-phase)


│   ├── train_stage4_promptsg/              ✅ Stage 4: PromptSG-based fine-tuning


│   └── baseline/, finetuned/, eval/
│

