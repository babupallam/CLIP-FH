"""
Auto-generated file.
"""
